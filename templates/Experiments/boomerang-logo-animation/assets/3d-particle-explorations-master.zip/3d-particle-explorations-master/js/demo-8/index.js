const Loader = require('../loader');
const System = require('./system');

window.demoNum = 8;
let loader = new Loader(System);
