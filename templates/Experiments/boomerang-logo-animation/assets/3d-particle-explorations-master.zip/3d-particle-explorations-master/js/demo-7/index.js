const Loader = require('../loader');
const System = require('./system');

window.demoNum = 7;
let loader = new Loader(System);
