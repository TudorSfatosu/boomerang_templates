const Loader = require('../loader');
const System = require('./system');

window.demoNum = 3;
let loader = new Loader(System);
